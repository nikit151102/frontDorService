import { CommonModule } from '@angular/common';
import { Component, Input, OnChanges, OnInit, SimpleChanges, ViewChild } from '@angular/core';
import { InvoicesComponent } from '../../../components/invoices/invoices.component';
import { ProductsComponent } from '../../../components/products/products.component';
import { JwtService } from '../../../../../services/jwt.service';
import { BUTTON_SETS } from './button-config';
import { InvoicesService } from '../../../components/invoices/invoices.service';
import { ProductsService } from '../../../components/products/products.service';
import { taxes } from '../../../../../services/data';

@Component({
  selector: 'app-invoices-content',
  imports: [CommonModule, InvoicesComponent, ProductsComponent],
  templateUrl: './invoices-content.component.html',
  styleUrl: './invoices-content.component.scss'
})
export class InvoicesContentComponent implements OnInit, OnChanges {
  @Input() counterpartyId!: any;
  @Input() counterpartyData!: any;
  @Input() notificationItem: any;
  selectedComponent: string = 'invoices';
  showDetails: boolean = false;
  cardTotalInfo: any;
  constructor(private jwtService: JwtService,
    public invoicesService: InvoicesService,
    public productsService: ProductsService,
  ) { }

  ngOnInit(): void {
    this.invoicesService.defaultFilters = [];
    this.invoicesService.queryData.filters = [];
    this.invoicesService.defaultFilters = [{
      field: 'Partner.Type',
      values: [0, 1, 5],
      type: 1
    },
    {
      field: 'DocPaymentType',
      values: [0, 1],
      type: 1
    },
    ];

    this.invoicesService.filterStatic = [{
      field: 'Partner.Type',
      values: [0, 1, 5],
      type: 1
    },
    {
      field: 'DocPaymentType',
      values: [0, 1],
      type: 1
    },
    ];


    this.productsService.defaultFilters = [];
    this.productsService.queryData.filters = [];

    this.productsService.queryData.filters = [{
      field: 'DocInvoice.Partner.Type',
      values: [0, 1, 5],
      type: 1
    },
    {
      field: 'ManagerDocType',
      values: [0],
      type: 1
    }
    ]



    console.log('this.jwtService.getDecodedToken()',this.jwtService.getDecodedToken().email)
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['notificationItem']) {
      console.log('Notifications изменились:');
      // if(this.notificationItem.partner.id == this.counterpartyId){
      //   this.invoicesService.updateOrAddItem(this.notificationItem);
      // }
    }
    if (changes['counterpartyData']) {
      this.showDetails = false;
    }

  }

  getButtonConfigs() {
    return BUTTON_SETS
  }

  showComponent(component: string) {
    this.selectedComponent = component;
  }

  columns = [
    { field: 'productTarget.Id', fieldView: 'productTarget', filterType: 10, searchField: 'productTarget.Name', header: 'Назначение', type: 'uuid', visible: true, width: '16%', endpoint: '/api/Entities/ProductTarget/Filter' },
    { field: 'name', fieldView: 'name', header: 'Товар', type: 'string', visible: true, width: '17%' },
    { field: 'quantity', fieldView: 'quantity', header: 'Количество', type: 'number', visible: true, width: '11%' },
    { field: 'measurementUnit.Id', fieldView: 'measurementUnit', filterType: 10, searchType: 'measurementUnit.Name', header: 'Ед.изм', type: 'uuid', visible: true, width: '11%', endpoint: '/api/Entities/MeasurementUnit/Filter' },
    { field: 'sumAmount', fieldView: 'sumAmount', header: 'Общая сумма', type: 'number', visible: true, width: '11%' },
    { field: 'DocInvoice.Number', fieldView: 'docInvoice', header: 'Номер фактуры', type: 'string', visible: true, width: '10%', isFilter: false },
    { field: 'DocInvoice.DateTime', fieldView: 'dateTime', header: 'Дата фактуры', type: 'date', visible: true, width: '13%' },
    { field: 'DocInvoice.Status', fieldView: 'docInvoiceStatus', header: 'Статус фактуры', type: 'enam', visible: true, width: '16%' },
    { field: 'DocInvoice.CreatorName', fieldView: 'creatorName', header: 'Создатель', type: 'string', visible: true, width: '16%' },

  ];


  totalInfoColumn = [
    { columnNum: 0, value: 'totalCount' },
    { columnNum: 2, value: 'totalExpenseSum' },
    { columnNum: 4, value: 'totalIncomeSum' },
  ];



  columnsInvoices = [
    { field: 'number', header: 'Номер', type: 'string', visible: true, width: '20%', isFilter: false },
    { field: 'expenseSum', header: 'Расход', type: 'number', visible: true, width: '15%' },
    { field: 'incomeSum', header: 'Приход', type: 'number', visible: true, width: '15%' },
    { field: 'status', header: 'Статус', type: 'enam', visible: true, width: '15%' },
    { field: 'dateTime', header: 'Дата', type: 'date', visible: true, width: '15%' },
    { field: 'creatorName', header: 'Создатель', type: 'string', visible: true, width: '15%' },
    { field: 'actions', header: '', type: 'actions', visible: true, width: '' },
  ];



  totalInfoColumnInvoices = [
    { columnNum: 0, value: 'totalCount' },
    { columnNum: 1, value: 'totalExpenseSum' },
    { columnNum: 2, value: 'totalIncomeSum' },
    { columnNum: 3, value: 'totalSaldo' },
  ]

  getTaxValue(tax: any) {
    const foundTax = taxes.find((item: any) => item.value === tax);
    return foundTax ? foundTax.label : '';
  }

  toggleDetails() {
    this.showDetails = !this.showDetails;
  }


}
