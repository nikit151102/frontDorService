import { CommonModule } from '@angular/common';
import { Component, ChangeDetectionStrategy, OnInit, OnDestroy, ChangeDetectorRef, HostListener } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { JwtService } from '../../../../services/jwt.service';
import { TokenService } from '../../../../services/token.service';
import { NavMenuService } from './nav-menu.service';
import { Subscription } from 'rxjs';
import { CacheReferenceService } from '../../../../services/cache-reference.service';
import { ToastService } from '../../../../services/toast.service';
import { SessionsComponent } from './sessions/sessions.component';

interface CustomMenuItem {
  label: string;
  commandName?: string;
  access: string;
  notifyKey?: string;
}

interface FullNotifyData {
  partnersNotifyData: NotifyData, // Данные уведомлений для Контрагентов
  servicesNotifyData: NotifyData // Данные уведомлений для Сервисов
}

interface NotifyData {
  notDeliveredCount: number, // Количество непрочитанных
  needActionCount: number // Количество Требуются действия
}

@Component({
  selector: 'app-nav-menu',
  standalone: true,
  imports: [CommonModule, SessionsComponent],
  templateUrl: './nav-menu.component.html',
  styleUrls: ['./nav-menu.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class NavMenuComponent implements OnInit, OnDestroy {

  items: CustomMenuItem[] = [
    { label: 'Контрагенты', commandName: 'clients', access: 'PartnersAccess', notifyKey: 'partnersNotifyData' },
    { label: 'Бухгалтер', commandName: 'accountant', access: 'AccountantAccess', notifyKey: '' },
    { label: 'Касса', commandName: 'cash', access: 'CashAccess' },
    // { label: 'База', commandName: 'base', access: 'ManagerAccess' },
    { label: 'Логист', commandName: 'logistic', access: 'LogisticAccess' },
    // LogisticAccess
    { label: 'Директор', commandName: 'director', access: 'Director2Access' },
    { label: 'Статистика', commandName: 'stats', access: 'DirectorAccess' },
    { label: 'Справочники', commandName: 'reference', access: 'EntitiesAccess' }

  ];
  // items: CustomMenuItem[] = [
  //   { label: 'Контрагенты', commandName: 'clients', access: '', notifyKey: 'partnersNotifyData' },
  //   { label: 'Бухгалтер', commandName: 'accountant', access: '', notifyKey: '' },
  //   { label: 'Касса', commandName: 'cash', access: '' },
  //   { label: 'База', commandName: 'base', access: '' },
  //   { label: 'Логист', commandName: 'base', access: 'none' },
  //   { label: 'Директор', commandName: 'base', access: 'none' },
  //   { label: 'Справочники', commandName: 'reference', access: '' }

  // ];
  decodedRole: any[] = [];
  notifications: any;
  menuActive: Boolean = false;

  private notificationSubscription!: Subscription;

  constructor(private activatedRoute: ActivatedRoute,
    public jwtService: JwtService, private router: Router,
    private cdr: ChangeDetectorRef,
    private tokenService: TokenService,
    private navMenuService: NavMenuService,
    private cacheService: CacheReferenceService,
    private toastService: ToastService,

  ) { }


  ngOnInit(): void {
    const decodedToken = this.jwtService.getDecodedToken();
    if (decodedToken && decodedToken.role) {
      if (Array.isArray(decodedToken.role)) {
        this.decodedRole = decodedToken.role;
      } else {
        console.error('Ошибка: role не массив!', decodedToken.role);
      }
    } else {
      console.error('Ошибка: Токен не содержит role!', decodedToken);
    }

    this.navMenuService.connectToWebSocket();

    this.notificationSubscription = this.navMenuService.notifications$.subscribe((data: any) => {
      this.notifications = data;
      this.cdr.detectChanges();
    });
    this.notifications = this.navMenuService.getNotifications();
    console.log('notifications', this.notifications)
  }

  toggleMenu() {
    this.menuActive = !this.menuActive;
  }

  hasAccess(access: string): boolean {
    return !access || this.decodedRole.includes(access);
    // return true
  }

  tooltipVisible = false;
  tooltipData: NotifyData | null = null;
  tooltipX = 0;
  tooltipY = 0;

  shouldShowNotification(notifyKey?: string): boolean {
    return notifyKey ? this.getNotificationCount(notifyKey) > 0 : false;
  }

  getNotificationCount(notifyKey: any): number {
    const data = this.navMenuService.getNotifications();
    return data && data[notifyKey]
      ? (data[notifyKey].notDeliveredCount || 0) + (data[notifyKey].needActionCount || 0)
      : 0;
  }


  getNotificationClass(notifyKey?: string): string {
    if (!this.notifications || !notifyKey || !(notifyKey in this.notifications)) {
      return '';
    }

    const data = this.notifications[notifyKey as keyof FullNotifyData] as NotifyData;
    if (data?.needActionCount > 0) {
      return 'notification-warning'; // Есть и непрочитанные, и требующие действий
    }
    return 'notification-info'; // Только непрочитанные
  }


  showTooltip(notifyKey: string | undefined, event: MouseEvent): void {
    if (!notifyKey || !this.notifications || !(notifyKey in this.notifications)) {
      return;
    }

    this.tooltipData = this.notifications[notifyKey as keyof FullNotifyData] as NotifyData;
    this.tooltipX = event.clientX + 10;
    this.tooltipY = event.clientY + 10;
    this.tooltipVisible = true;
  }


  hideTooltip(): void {
    this.tooltipVisible = false;
    this.tooltipData = null;
  }



  execute(commandName: string) {
    if (commandName == 'exit') {
      this.router.navigate(['/']);
      this.tokenService.clearToken();
      window.history.pushState(null, '', '/');
      this.cacheService.clear();
    } else {
      this.activatedRoute.paramMap.subscribe(params => {
        const id = params.get('id');
        if (id) {
          this.router.navigate([`${id}/${commandName}`]);
        }
      });
    }
  }


  ngOnDestroy(): void {
    if (this.notificationSubscription) {
      this.notificationSubscription.unsubscribe();
    }

    this.navMenuService.disconnectWebSocket();
  }




  isDropdownVisible = false;

  onProfileClick(event: MouseEvent): void {
    this.isDropdownVisible = !this.isDropdownVisible;
    event.stopPropagation();
  }

  @HostListener('document:click', ['$event'])
  onClickOutside(event: MouseEvent): void {
    const target = event.target as Element;
    if (target && !target.closest('.navbar-profile')) {
      this.isDropdownVisible = false;
    }
  }

  refreshReference() {
    this.cacheService.clear();
    this.toastService.showSuccess('Обновление справочников', 'Начато обновление данных...');

    this.cacheService.refreshAllCachedData().subscribe({
      next: (results) => {
        console.log('Обновленные данные:', results);

        if (results.length > 0) {
          this.toastService.showSuccess(
            'Обновление завершено',
            `Успешно обновлено ${results.length} справочников`
          );
        } else {
          this.toastService.showSuccess(
            'Нет данных для обновления',
            'Не найдено закэшированных справочников'
          );
        }
      },
      error: (err) => {
        console.error('Ошибка при обновлении данных:', err);

        this.toastService.showError(
          'Ошибка обновления',
          'Произошла ошибка при обновлении справочников'
        );
      }
    });
  }

}
